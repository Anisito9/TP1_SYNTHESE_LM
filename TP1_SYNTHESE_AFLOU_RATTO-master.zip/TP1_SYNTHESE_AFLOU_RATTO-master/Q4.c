#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>


#define welcome "Bienvenue dans le Shell ENSEA.\n Pour quitter, tapez 'exit'\n"
#define EXIT_MSG "Bye bye ...\n "
#define ERROR_MSG_F "Fork creation failed"



void display_exit_sign(int status) { // Function that gets the exit status (WEXITSTATUS) or signal (WTERMSIG) form a status


    char buffer2[128];
    size_t length = 0;

    if (WIFEXITED(status)) {  // WIFEXITED return True if exit status is received
        int exit_stat = WEXITSTATUS(status);
        length = snprintf(buffer2, sizeof(buffer2), "enseash [exit:%d] %% ", exit_stat);
    } 
    else if (WIFSIGNALED(status)) {
        int signal = WTERMSIG(status);
        length = snprintf(buffer2, sizeof(buffer2), "enseash [sign:%d] %% ", signal);
    }

	write(STDOUT_FILENO, buffer2, length);
	
}


int main() {
	char buffer[1024];
	size_t USER_INPUT;
	int status_c = 0;
	
	write(STDOUT_FILENO, welcome, strlen(welcome)); // STDOUT_FILENO indicates that the data have to be sent to standard output
	
	
	while (1) {
        display_exit_sign(status_c); // Call of the function display_exit_sign
        

        USER_INPUT = read(STDIN_FILENO, buffer, sizeof(buffer)); // The input is stored in the buffer
        
        
        if (USER_INPUT <= 0) {
        break; // If ctrl+D is detected, EoF, USER_INPUT = 0 => break
         
        } 
        
        buffer[USER_INPUT - 1] = '\0'; // Remove of the \n because of the touch enter

	if (strcmp(buffer, "exit") == 0) {  // strcmp = 0 if buffer = 'exit'
            write(STDOUT_FILENO, EXIT_MSG, strlen(EXIT_MSG));
            break;
        }
	
	// Creation of son process
	
	pid_t pid = fork(); 
	
	// 
	
	if(pid ==-1){   // error during the process
	
		write(STDOUT_FILENO,ERROR_MSG_F, strlen(ERROR_MSG_F));
		break;	
	}
	
	if(pid ==0) {	// executing the command stored in buffer, NULL because no args
		execlp(buffer, buffer, (char*) NULL); 
		perror("Execuction of the command failed"); // Error if execvp fail
		break;
	}
	
	if (pid >0) {
		waitpid(pid, &status_c, 0); // &status modify the value of status_c
	
	}
	}
	return 0;
}
