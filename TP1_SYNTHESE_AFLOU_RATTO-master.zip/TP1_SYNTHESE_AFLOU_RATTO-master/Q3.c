#include <stdio.h>
#include <string.h>
#include <unistd.h>



#define welcome "Bienvenue dans le Shell ENSEA.\n Pour quitter, tapez 'exit'\n"
#define PROMPT "enseash % "
#define EXIT_MSG "Bye bye ...\n "

int main() {
	char buffer[1024];
	size_t USER_INPUT;
	write(STDOUT_FILENO, welcome, strlen(welcome)); // STDOUT_FILENO indicates that the data have to be sent to standard output
	
	
	
	while (1) {
        
        write(STDOUT_FILENO, PROMPT, strlen(PROMPT));

        USER_INPUT = read(STDIN_FILENO, buffer, sizeof(buffer)); // The input is stored in the buffer
        
        
        if (USER_INPUT <= 0) {
        break; // If ctrl+D is detected, EoF, USER_INPUT = 0 => break
         
        } 
        
        buffer[USER_INPUT - 1] = '\0'; // Remove of the \n because of the touch enter

	if (strcmp(buffer, "exit") == 0) {  // strcmp = 0 if buffer = 'exit'
            write(STDOUT_FILENO, EXIT_MSG, strlen(EXIT_MSG));
            break;
        }
	

	}
	return 0;
}
