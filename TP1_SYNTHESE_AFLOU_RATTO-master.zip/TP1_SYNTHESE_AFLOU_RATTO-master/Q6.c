#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <time.h>
#include <stdlib.h>

#define welcome "Bienvenue dans le Shell ENSEA.\n Pour quitter, tapez 'exit'\n"
#define EXIT_MSG "Bye bye ...\n "
#define ERROR_MSG_F "Fork creation failed"
#define ARGS_MAX 8 // 8 args maximum


void display_exit_sign(int status, long exec_time_ms) { // Function that gets the exit status (WEXITSTATUS) or signal (WTERMSIG) form a status


    char buffer2[128];
    size_t length = 0;

    if (WIFEXITED(status)) {  // WIFEXITED return True if exit status is received
        int exit_stat = WEXITSTATUS(status);
        length = snprintf(buffer2, sizeof(buffer2), "enseash [exit:%d|%ldms] %% ", exit_stat, exec_time_ms);
    } 
    else if (WIFSIGNALED(status)) {
        int signal = WTERMSIG(status);
        length = snprintf(buffer2, sizeof(buffer2), "enseash [sign:%d|%ldms] %% ", signal, exec_time_ms);
    }

	write(STDOUT_FILENO, buffer2, length);
	
}


int main() {
	char buffer[1024];
	size_t USER_INPUT;
	int status_c = 0;
	long exec_time_ms = 0;
	
	write(STDOUT_FILENO, welcome, strlen(welcome)); // STDOUT_FILENO indicates that the data have to be sent to standard output
	
	
	while (1) {
        display_exit_sign(status_c, exec_time_ms); // Call of the function display_exit_sign
        

        USER_INPUT = read(STDIN_FILENO, buffer, sizeof(buffer)); // The input is stored in the buffer
        
        
        if (USER_INPUT <= 0) {
        	break; // If ctrl+D is detected, EoF, USER_INPUT = 0 => break
         
        	} 
        
        buffer[USER_INPUT - 1] = '\0'; // Remove of the \n because of the touch enter

	if (strcmp(buffer, "exit") == 0) {  // strcmp = 0 if buffer = 'exit'
            write(STDOUT_FILENO, EXIT_MSG, strlen(EXIT_MSG));
            break;
        }
	
	char *argv[ARGS_MAX];
	int argc = 0; // Number of args
	char *words = strtok(buffer, " ");  // Separates the command by " " 
	while (words != NULL ) {
            argv[argc++] = words;  // We add the separated words as args
            words = strtok(NULL, " "); // separate other args
        }
	argv[argc] = NULL; // last item is NULL for execvp
	// Creation of son process
	
	pid_t pid = fork(); 
	
	// 
	
	if(pid ==-1){   // error during the process
	
		write(STDOUT_FILENO,ERROR_MSG_F, strlen(ERROR_MSG_F));
		break;	
		}
	
	if(pid ==0) {	// executing the command stored in buffer, NULL because no args
		execvp(argv[0], argv);
		perror("Execuction of the command failed"); // Error if execvp fail
		break;
		}
	
	if (pid >0) {
		struct timespec start, end;
		clock_gettime(CLOCK_MONOTONIC, &start); // begining time
		waitpid(pid, &status_c, 0); // &status modify the value of status_c
		clock_gettime(CLOCK_MONOTONIC, &end); // end time
		exec_time_ms = (end.tv_sec - start.tv_sec) * 1000+ // seconds to mili seconds
		(end.tv_nsec - start.tv_nsec) / 1000000; // Nano secondes to mili seconds
		}
	}
	return 0;
}
