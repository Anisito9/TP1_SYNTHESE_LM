#include <stdio.h>
#include <string.h>
#include <unistd.h>


#define welcome "Bienvenue dans le Shell ENSEA.\n Pour quitter, tapez 'exit'\n\r"
#define PROMPT "enseash % "

int main() {

	write(STDOUT_FILENO, welcome, strlen(welcome)); // STDOUT_FILENO indicates that the data have to be sent to standard output
	
	write(STDOUT_FILENO, PROMPT, strlen(PROMPT));
	
	return 0;
}
