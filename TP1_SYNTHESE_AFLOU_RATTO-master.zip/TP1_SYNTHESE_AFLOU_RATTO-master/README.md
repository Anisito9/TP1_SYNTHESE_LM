AFLOU - RATTO
Report LAB1

Q1,2,3) Not many things to say.

Q4) It is getting interesting. The goal is to get the exit and the sign status of a command. Let's analyze this piece of code to understand the overall approach.


	if(pid ==0) {	
		execlp(buffer, buffer, (char*) NULL); 
		perror("Execuction of the command failed"); 
		break;
	}
	
	if (pid >0) {
		waitpid(pid, &status_c, 0); // 
		
Here, we entrust the task of executing the command to the child process by using execlp function. Then, the father process waits the end of the task (waitpid) and gets status.

Then we can simply display the exit and sign code : 

- int exit_stat = WEXITSTATUS(status);
- int signal = WTERMSIG(status);

Q5) The question 5 is quite simple, we just need to start a timer before the waitpid and end it after the waitpid. Then we convert the time to ms. Here is a preview of the code : 


	struct timespec start, end;
		clock_gettime(CLOCK_MONOTONIC, &start); // beginning time
		waitpid(pid, &status_c, 0); 
		clock_gettime(CLOCK_MONOTONIC, &end); // end time
		exec_time_ms = (end.tv_sec - start.tv_sec) * 1000+ // seconds to mili seconds
		(end.tv_nsec - start.tv_nsec) / 1000000; // Nano secondes to mili seconds
		
		
Q6) It is getting even more interesting, now, we want to add args to a command, lets describe this piece of code : 

char *argv[ARGS_MAX];
	int argc = 0; // Number of args
	char *words = strtok(buffer, " ");  
	while (words != NULL ) {
            argv[argc++] = words;  
            words = strtok(NULL, " "); 
        }
	argv[argc] = NULL; 
	
The code is quit simple, we create a char of the length of ARGS_MAX, 8 is enough for us. We initialize argc, the number of arguments. Then we separate the command stored in buffer by space.
If i put hostname -i, it will separate hostname and -i. Then while there is words  in words, we add those in argv. Then if i write test T1 T2, argv[1] = T1 and argv[2] = T2.
We finish by argv[argc] = NULL, to say that the last item of argv is NULL for execvp function.
